/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['localhost'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  experimental: {
    serverComponentsExternalPackages: ['@libsql/client', '@prisma/client', '@prisma/adapter-libsql'],
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
};

export default nextConfig;
