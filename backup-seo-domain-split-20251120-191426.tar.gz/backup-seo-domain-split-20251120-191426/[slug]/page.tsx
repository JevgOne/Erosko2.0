import PageWrapper from './page-wrapper';

export default PageWrapper;
