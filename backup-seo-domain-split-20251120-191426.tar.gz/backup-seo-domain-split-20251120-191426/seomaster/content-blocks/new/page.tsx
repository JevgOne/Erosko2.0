import ContentBlockEditor from '../../components/ContentBlockEditor';

export default function NewContentBlockPage() {
  return <ContentBlockEditor />;
}
